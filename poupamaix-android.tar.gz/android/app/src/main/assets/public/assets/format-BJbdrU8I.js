function e(r,t="BRL"){return new Intl.NumberFormat("pt-BR",{style:"currency",currency:t}).format(r)}export{e as f};
