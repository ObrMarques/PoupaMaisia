import { Router } from "express";
import {
  db,
  aiConversationsTable,
  aiMessagesTable,
  transactionsTable,
  walletsTable,
  goalsTable,
  categoriesTable,
} from "@workspace/db";
import { eq, and, desc, sql } from "drizzle-orm";
import { authMiddleware, getUser } from "../lib/auth";
import { ai } from "@workspace/integrations-gemini-ai";

const router = Router();

// ── Transaction detection ────────────────────────────────────────────────────

interface DetectedTransaction {
  id: number;
  type: "income" | "expense";
  amount: number;
  description: string;
  categoryId: number;
  categoryName: string;
  categoryColor: string;
  date: string;
  walletId: number;
}

async function detectAndSaveTransaction(
  userId: number,
  message: string
): Promise<DetectedTransaction | null> {
  const [categories, wallets] = await Promise.all([
    db
      .select()
      .from(categoriesTable)
      .where(sql`${categoriesTable.userId} IS NULL OR ${categoriesTable.userId} = ${userId}`),
    db
      .select()
      .from(walletsTable)
      .where(eq(walletsTable.userId, userId))
      .limit(1),
  ]);

  if (!wallets.length) return null;

  const today = new Date().toISOString().split("T")[0];
  const catNames = categories.map((c) => c.name).join(", ");

  const extractionPrompt = `Analise a mensagem e identifique se o usuário está registrando uma transação financeira.

Categorias disponíveis: ${catNames}

Se for uma transação, responda APENAS com JSON válido (sem markdown):
{"tipo":"despesa" ou "receita","valor":number,"categoria":"nome exato da lista acima","descricao":"texto curto","data":"${today}"}

Se NÃO for registro de transação (pergunta, análise, dúvida etc.), responda apenas: null

Mensagem: "${message.replace(/"/g, "'")}"`;

  let rawJson = "";
  try {
    const result = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [{ role: "user", parts: [{ text: extractionPrompt }] }],
      config: { maxOutputTokens: 200 },
    });
    rawJson = result.text?.trim() ?? "";
  } catch {
    return null;
  }

  if (!rawJson || rawJson === "null") return null;

  // Strip markdown code fences if present
  const cleaned = rawJson.replace(/^```[a-z]*\n?/i, "").replace(/```$/m, "").trim();

  let parsed: { tipo: string; valor: number; categoria: string; descricao: string; data: string };
  try {
    parsed = JSON.parse(cleaned);
  } catch {
    return null;
  }

  if (!parsed.tipo || !parsed.valor || !parsed.categoria) return null;

  const type = parsed.tipo === "receita" ? "income" : "expense";
  const amount = Math.abs(Number(parsed.valor));
  if (!amount || isNaN(amount)) return null;

  // Match category (case-insensitive, partial match)
  const match =
    categories.find(
      (c) => c.name.toLowerCase() === parsed.categoria.toLowerCase()
    ) ??
    categories.find((c) =>
      c.name.toLowerCase().includes(parsed.categoria.toLowerCase().slice(0, 4))
    ) ??
    categories.find((c) => c.name.toLowerCase() === "outros") ??
    categories[0];

  if (!match) return null;

  const wallet = wallets[0];
  const date = parsed.data || today;

  const [tx] = await db
    .insert(transactionsTable)
    .values({
      userId,
      type,
      amount: String(amount),
      description: parsed.descricao || parsed.categoria,
      date,
      categoryId: match.id,
      walletId: wallet.id,
      isRecurring: false,
    })
    .returning();

  return {
    id: tx.id,
    type,
    amount,
    description: tx.description ?? parsed.categoria,
    categoryId: match.id,
    categoryName: match.name,
    categoryColor: match.color ?? "#6C5CE7",
    date,
    walletId: wallet.id,
  };
}

// ────────────────────────────────────────────────────────────────────────────

async function buildFinancialContext(userId: number): Promise<string> {
  const now = new Date();
  const firstOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

  const [transactions, wallets, goals, categories] = await Promise.all([
    db
      .select()
      .from(transactionsTable)
      .where(eq(transactionsTable.userId, userId))
      .orderBy(desc(transactionsTable.date))
      .limit(50),
    db.select().from(walletsTable).where(eq(walletsTable.userId, userId)),
    db.select().from(goalsTable).where(eq(goalsTable.userId, userId)),
    db
      .select()
      .from(categoriesTable)
      .where(
        sql`${categoriesTable.userId} IS NULL OR ${categoriesTable.userId} = ${userId}`
      ),
  ]);

  const catMap = Object.fromEntries(categories.map((c) => [c.id, c.name]));

  const monthTx = transactions.filter((t) => new Date(t.date) >= firstOfMonth);
  const monthIncome = monthTx
    .filter((t) => t.type === "income")
    .reduce((s, t) => s + parseFloat(t.amount), 0);
  const monthExpense = monthTx
    .filter((t) => t.type === "expense")
    .reduce((s, t) => s + parseFloat(t.amount), 0);

  const totalBalance = wallets.reduce(
    (s, w) => s + parseFloat(w.initialBalance ?? "0"),
    0
  );

  const recentTx = transactions.slice(0, 15).map((t) => ({
    tipo: t.type === "income" ? "RECEITA" : "DESPESA",
    valor: parseFloat(t.amount).toFixed(2),
    categoria: catMap[t.categoryId ?? 0] ?? "Sem categoria",
    data: new Date(t.date).toLocaleDateString("pt-BR"),
    descricao: t.description ?? "",
  }));

  const goalsInfo = goals.map((g) => ({
    nome: g.name,
    meta: parseFloat(g.targetAmount).toFixed(2),
    atual: parseFloat(g.currentAmount).toFixed(2),
    progresso: Math.round(
      (parseFloat(g.currentAmount) / parseFloat(g.targetAmount)) * 100
    ),
    prazo: g.deadline
      ? new Date(g.deadline).toLocaleDateString("pt-BR")
      : "Sem prazo",
  }));

  const walletsInfo = wallets.map((w) => ({
    nome: w.name,
    saldo: parseFloat(w.initialBalance ?? "0").toFixed(2),
  }));

  const expenseByCategory: Record<string, number> = {};
  monthTx
    .filter((t) => t.type === "expense")
    .forEach((t) => {
      const cat = catMap[t.categoryId ?? 0] ?? "Sem categoria";
      expenseByCategory[cat] = (expenseByCategory[cat] ?? 0) + parseFloat(t.amount);
    });

  const topCategories = Object.entries(expenseByCategory)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 5);

  return `
=== DADOS FINANCEIROS DO USUÁRIO (${new Date().toLocaleDateString("pt-BR")}) ===

RESUMO DO MÊS ATUAL (${now.toLocaleString("pt-BR", { month: "long", year: "numeric" })}):
- Receitas: R$ ${monthIncome.toFixed(2)}
- Despesas: R$ ${monthExpense.toFixed(2)}
- Saldo do mês: R$ ${(monthIncome - monthExpense).toFixed(2)}
- Total de transações no mês: ${monthTx.length}

MAIORES CATEGORIAS DE GASTO NO MÊS:
${topCategories.length ? topCategories.map(([cat, val]) => `- ${cat}: R$ ${val.toFixed(2)}`).join("\n") : "- Sem dados de categorias"}

CARTEIRAS E SALDOS:
${walletsInfo.length ? walletsInfo.map((w) => `- ${w.nome}: R$ ${w.saldo}`).join("\n") : "- Nenhuma carteira cadastrada"}
Patrimônio total: R$ ${totalBalance.toFixed(2)}

METAS FINANCEIRAS:
${goalsInfo.length ? goalsInfo.map((g) => `- ${g.nome}: R$ ${g.atual}/${g.meta} (${g.progresso}%) — Prazo: ${g.prazo}`).join("\n") : "- Nenhuma meta cadastrada"}

ÚLTIMAS TRANSAÇÕES:
${recentTx.length ? recentTx.map((t) => `- ${t.data} | ${t.tipo} | R$ ${t.valor} | ${t.categoria}${t.descricao ? ` — ${t.descricao}` : ""}`).join("\n") : "- Nenhuma transação registrada"}
=====================================`;
}

const SYSTEM_PROMPT = `Você é o PoupaAI, assistente financeiro do PoupaMais.

REGRAS DE RESPOSTA:
- Seja sempre curto e direto. Máximo 3-4 linhas por resposta, salvo se o usuário pedir mais detalhes.
- Vá direto ao ponto. Sem introduções, sem repetir a pergunta, sem enrolação.
- Use os dados financeiros reais do usuário para personalizar a resposta.
- Nunca repita dados brutos — interprete e dê uma conclusão prática.
- Só aprofunde quando o usuário pedir explicitamente ("explique mais", "como funciona", etc.).
- Português brasileiro, tom direto e prático, como um amigo que entende de dinheiro.
- Valores em R$, referências brasileiras (CDI, Selic, Tesouro Direto, IPCA, PIX).
- Se os dados forem insuficientes para responder, diga em uma linha e oriente o próximo passo.`;

router.post("/ai/stream", authMiddleware, async (req, res) => {
  const user = getUser(req);
  const { message, conversationId } = req.body as {
    message: string;
    conversationId?: number;
  };

  if (!message?.trim()) {
    res.status(400).json({ error: "Mensagem não pode ser vazia" });
    return;
  }

  let convId = conversationId;

  if (!convId) {
    const [conv] = await db
      .insert(aiConversationsTable)
      .values({
        userId: user.id,
        title: message.slice(0, 60),
        updatedAt: new Date(),
      })
      .returning();
    convId = conv.id;
  } else {
    const conv = await db
      .select()
      .from(aiConversationsTable)
      .where(
        and(
          eq(aiConversationsTable.id, convId),
          eq(aiConversationsTable.userId, user.id)
        )
      )
      .limit(1);
    if (!conv.length) {
      res.status(404).json({ error: "Conversa não encontrada" });
      return;
    }
    await db
      .update(aiConversationsTable)
      .set({ updatedAt: new Date() })
      .where(eq(aiConversationsTable.id, convId));
  }

  await db.insert(aiMessagesTable).values({
    conversationId: convId,
    role: "user",
    content: message,
  });

  const [financialContext, allHistory] = await Promise.all([
    buildFinancialContext(user.id),
    db
      .select()
      .from(aiMessagesTable)
      .where(eq(aiMessagesTable.conversationId, convId))
      .orderBy(aiMessagesTable.createdAt),
  ]);

  const historyMessages = allHistory
    .slice(0, -1)
    .map((m) => ({
      role: m.role as "user" | "assistant",
      content: m.content,
    }));

  // Disable proxy buffering so chunks reach the client immediately
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache, no-transform");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("X-Accel-Buffering", "no");
  res.setHeader("Transfer-Encoding", "chunked");
  res.flushHeaders();

  // Send a heartbeat comment so the connection is accepted immediately
  res.write(": connected\n\n");
  (res as any).flush?.();

  let fullResponse = "";

  try {
    const geminiContents = [
      ...historyMessages.map((m) => ({
        role: m.role === "assistant" ? "model" as const : "user" as const,
        parts: [{ text: m.content }],
      })),
      { role: "user" as const, parts: [{ text: message }] },
    ];

    const stream = await ai.models.generateContentStream({
      model: "gemini-2.5-flash",
      contents: geminiContents,
      config: {
        systemInstruction: SYSTEM_PROMPT + "\n\n" + financialContext,
        maxOutputTokens: 8192,
      },
    });

    for await (const chunk of stream) {
      const text = chunk.text;
      if (text) {
        fullResponse += text;
        res.write(`data: ${JSON.stringify({ content: text })}\n\n`);
        (res as any).flush?.();
      }
    }
  } catch (_err) {
    res.write(
      `data: ${JSON.stringify({
        error: "Erro ao processar sua mensagem. Tente novamente.",
      })}\n\n`
    );
    (res as any).flush?.();
    res.end();
    return;
  }

  if (fullResponse) {
    await db.insert(aiMessagesTable).values({
      conversationId: convId,
      role: "assistant",
      content: fullResponse,
    });
  }

  // Detect and auto-save transaction if message contains one
  try {
    const detected = await detectAndSaveTransaction(user.id, message);
    if (detected) {
      res.write(`data: ${JSON.stringify({ type: "transaction_saved", transaction: detected })}\n\n`);
      (res as any).flush?.();
    }
  } catch {
    // Detection failure is non-fatal — don't break the stream
  }

  res.write(
    `data: ${JSON.stringify({ done: true, conversationId: convId })}\n\n`
  );
  (res as any).flush?.();
  res.end();
});

router.get("/ai/conversations", authMiddleware, async (req, res) => {
  const user = getUser(req);

  const convs = await db
    .select()
    .from(aiConversationsTable)
    .where(eq(aiConversationsTable.userId, user.id))
    .orderBy(desc(aiConversationsTable.updatedAt));

  res.json(
    convs.map((c) => ({
      id: c.id,
      userId: c.userId,
      title: c.title,
      createdAt: c.createdAt.toISOString(),
      updatedAt: c.updatedAt.toISOString(),
    }))
  );
});

router.post("/ai/conversations", authMiddleware, async (req, res) => {
  const user = getUser(req);

  const [conv] = await db
    .insert(aiConversationsTable)
    .values({
      userId: user.id,
      title: "Nova conversa",
      updatedAt: new Date(),
    })
    .returning();

  res.status(201).json({
    id: conv.id,
    userId: conv.userId,
    title: conv.title,
    createdAt: conv.createdAt.toISOString(),
    updatedAt: conv.updatedAt.toISOString(),
  });
});

router.delete("/ai/conversations/:id", authMiddleware, async (req, res) => {
  const user = getUser(req);
  const id = parseInt(req.params["id"] as string);

  const conv = await db
    .select()
    .from(aiConversationsTable)
    .where(
      and(
        eq(aiConversationsTable.id, id),
        eq(aiConversationsTable.userId, user.id)
      )
    )
    .limit(1);

  if (!conv.length) {
    res.status(404).json({ error: "Conversa não encontrada" });
    return;
  }

  await db
    .delete(aiMessagesTable)
    .where(eq(aiMessagesTable.conversationId, id));
  await db
    .delete(aiConversationsTable)
    .where(eq(aiConversationsTable.id, id));

  res.status(204).end();
});

router.get(
  "/ai/conversations/:id/messages",
  authMiddleware,
  async (req, res) => {
    const user = getUser(req);
    const id = parseInt(req.params["id"] as string);

    const conv = await db
      .select()
      .from(aiConversationsTable)
      .where(
        and(
          eq(aiConversationsTable.id, id),
          eq(aiConversationsTable.userId, user.id)
        )
      )
      .limit(1);

    if (!conv.length) {
      res.status(404).json({ error: "Conversa não encontrada" });
      return;
    }

    const messages = await db
      .select()
      .from(aiMessagesTable)
      .where(eq(aiMessagesTable.conversationId, id))
      .orderBy(aiMessagesTable.createdAt);

    res.json(
      messages.map((m) => ({
        id: m.id,
        conversationId: m.conversationId,
        role: m.role,
        content: m.content,
        createdAt: m.createdAt.toISOString(),
      }))
    );
  }
);

export default router;
