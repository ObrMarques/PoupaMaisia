import { useState } from "react";
import { Link, useLocation } from "wouter";
import {
  LayoutDashboard, Receipt, Target, Wallet, PieChart,
  Sparkles, Settings, LogOut, HelpCircle, ArrowLeft, Menu, X, Bell, Crown
} from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useI18n } from "@/contexts/i18n-context";
import { Button } from "@/components/ui/button";

const PAGE_TITLES: Record<string, string> = {
  "/dashboard":    "Painel",
  "/":             "Painel",
  "/transactions": "Transações",
  "/goals":        "Metas",
  "/wallets":      "Carteiras",
  "/reports":      "Relatórios",
  "/ai":           "PoupaAI",
  "/premium":      "Premium",
  "/settings":     "Configurações",
  "/support":      "Suporte",
};

const HOME_ROUTES = new Set(["/", "/dashboard"]);

function useNavItems() {
  const { t } = useI18n();
  return [
    { href: "/dashboard",    icon: LayoutDashboard, label: t("nav.dashboard") },
    { href: "/transactions", icon: Receipt,          label: t("nav.transactions") },
    { href: "/goals",        icon: Target,           label: t("nav.goals") },
    { href: "/wallets",      icon: Wallet,           label: t("nav.wallets") },
    { href: "/reports",      icon: PieChart,         label: t("nav.reports") },
    { href: "/ai",           icon: Sparkles,         label: t("nav.ai") },
  ];
}

function useBottomItems() {
  const { t } = useI18n();
  return [
    { href: "/support",  icon: HelpCircle, label: t("nav.support") },
    { href: "/settings", icon: Settings,   label: t("nav.settings") },
  ];
}

/** Desktop sidebar nav link — compact */
function NavLink({
  href, icon: Icon, label, location, onClick,
}: {
  href: string; icon: any; label: string; location: string; onClick?: () => void;
}) {
  const isActive = location === href || (href !== "/" && location.startsWith(`${href}/`));
  return (
    <Link href={href} onClick={onClick}>
      <div
        className={`flex items-center gap-3 px-3 py-2.5 rounded-md transition-colors cursor-pointer text-sm ${
          isActive
            ? "bg-secondary text-foreground font-medium"
            : "text-muted-foreground hover:bg-secondary/50 hover:text-foreground"
        }`}
        data-testid={`nav-${href.replace("/", "")}`}
      >
        <Icon className="w-4 h-4 shrink-0" />
        {label}
      </div>
    </Link>
  );
}

/** Mobile drawer nav link — larger touch target (≥52px) */
function MobileNavLink({
  href, icon: Icon, label, location, onClick,
}: {
  href: string; icon: any; label: string; location: string; onClick?: () => void;
}) {
  const isActive = location === href || (href !== "/" && location.startsWith(`${href}/`));
  return (
    <Link href={href} onClick={onClick}>
      <div
        className={`flex items-center gap-4 px-4 min-h-[52px] rounded-xl transition-colors cursor-pointer text-base ${
          isActive
            ? "bg-secondary text-foreground font-semibold"
            : "text-muted-foreground hover:bg-secondary/60 hover:text-foreground"
        }`}
        data-testid={`nav-mobile-${href.replace("/", "")}`}
      >
        <Icon className={`w-5 h-5 shrink-0 ${isActive ? "text-foreground" : "text-muted-foreground"}`} />
        <span>{label}</span>
        {isActive && (
          <span className="ml-auto w-1.5 h-1.5 rounded-full bg-foreground" />
        )}
      </div>
    </Link>
  );
}

function MobileDrawer({
  open,
  onClose,
  location,
}: {
  open: boolean;
  onClose: () => void;
  location: string;
}) {
  const { logout, user } = useAuth();
  const { t } = useI18n();
  const navItems    = useNavItems();
  const bottomItems = useBottomItems();

  return (
    <>
      {/* Overlay */}
      <div
        className={`fixed inset-0 z-40 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${
          open ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
        }`}
        onClick={onClose}
        aria-hidden="true"
      />
      {/* Drawer panel — 82% viewport width, max 320px */}
      <div
        className={`fixed top-0 left-0 bottom-0 z-50 w-[82vw] max-w-[320px] bg-card border-r border-border flex flex-col shadow-2xl transition-transform duration-300 ease-out ${
          open ? "translate-x-0" : "-translate-x-full"
        }`}
        role="dialog"
        aria-modal="true"
        aria-label="Menu de navegação"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 pt-5 pb-4 border-b border-border shrink-0">
          <Link href="/dashboard" onClick={onClose} className="flex items-center gap-3">
            <span className="font-bold text-xl tracking-tight">PoupaMais</span>
          </Link>
          <button
            onClick={onClose}
            className="w-10 h-10 flex items-center justify-center rounded-xl text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors"
            aria-label="Fechar menu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Main nav items */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {navItems.map(item => (
            <MobileNavLink
              key={item.href}
              href={item.href}
              icon={item.icon}
              label={item.label}
              location={location}
              onClick={onClose}
            />
          ))}
          {/* Premium highlight */}
          <div className="pt-2">
            <Link href="/premium" onClick={onClose}>
              <div
                className={`flex items-center gap-4 px-4 min-h-[52px] rounded-xl transition-all duration-150 cursor-pointer text-base font-semibold ${
                  location === "/premium"
                    ? "bg-[#D4AF37]/15"
                    : "hover:bg-[#D4AF37]/10"
                }`}
                data-testid="nav-mobile-premium"
              >
                <Crown
                  className="w-5 h-5 shrink-0 transition-colors"
                  style={{ color: location === "/premium" ? "#C9A227" : "#D4AF3799" }}
                />
                <span
                  className="transition-colors"
                  style={{ color: location === "/premium" ? "#C9A227" : "#D4AF3799" }}
                >
                  Premium
                </span>
                {location === "/premium" && (
                  <span className="ml-auto w-1.5 h-1.5 rounded-full" style={{ backgroundColor: "#C9A227" }} />
                )}
              </div>
            </Link>
          </div>
        </nav>

        {/* Bottom nav items (support + settings) */}
        <div className="px-3 py-3 space-y-1 border-t border-border">
          {bottomItems.map(item => (
            <MobileNavLink
              key={item.href}
              href={item.href}
              icon={item.icon}
              label={item.label}
              location={location}
              onClick={onClose}
            />
          ))}
        </div>

        {/* User profile + logout */}
        <div className="p-4 border-t border-border bg-secondary/20">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-11 h-11 rounded-full bg-secondary flex items-center justify-center overflow-hidden shrink-0 ring-2 ring-border">
              {user?.avatarUrl ? (
                <img src={user.avatarUrl} alt={user?.name} className="w-full h-full object-cover" />
              ) : (
                <span className="font-semibold text-base">{user?.name?.charAt(0).toUpperCase()}</span>
              )}
            </div>
            <div className="overflow-hidden flex-1 min-w-0">
              <p className="text-sm font-semibold truncate leading-tight">{user?.name}</p>
              <p className="text-xs text-muted-foreground truncate mt-0.5">{user?.email}</p>
            </div>
          </div>
          <button
            className="w-full flex items-center gap-3 px-4 min-h-[48px] rounded-xl text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors text-sm font-medium"
            onClick={() => { onClose(); logout(); }}
            data-testid="button-logout-mobile"
          >
            <LogOut className="w-5 h-5 shrink-0" />
            {t("auth.logout")}
          </button>
        </div>
      </div>
    </>
  );
}

export function AppLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { logout, user } = useAuth();
  const { t } = useI18n();
  const navItems    = useNavItems();
  const bottomItems = useBottomItems();

  const [drawerOpen, setDrawerOpen] = useState(false);

  const isHome    = HOME_ROUTES.has(location);
  const pageTitle = PAGE_TITLES[location] ?? "PoupaMais";

  const handleBack = () => {
    if (window.history.length > 1) window.history.back();
  };

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">

      {/* Sidebar — desktop only */}
      <aside className="hidden md:flex flex-col w-60 border-r border-border bg-card shrink-0">
        <div className="p-5 pb-4">
          <Link href="/dashboard" className="flex items-center gap-2.5 font-bold text-lg tracking-tight">
            PoupaMais
          </Link>
        </div>

        <nav className="flex-1 px-3 space-y-0.5 overflow-y-auto">
          {navItems.map(item => (
            <NavLink key={item.href} href={item.href} icon={item.icon} label={item.label} location={location} />
          ))}
          {/* Premium highlight */}
          <div className="pt-2 pb-1">
            <Link href="/premium">
              <div
                className={`flex items-center gap-3 px-3 py-2.5 rounded-md transition-all duration-150 cursor-pointer text-sm font-medium group ${
                  location === "/premium"
                    ? "bg-[#D4AF37]/15"
                    : "hover:bg-[#D4AF37]/10"
                }`}
                data-testid="nav-premium"
              >
                <Crown
                  className="w-4 h-4 shrink-0 transition-colors"
                  style={{ color: location === "/premium" ? "#C9A227" : "#D4AF3799" }}
                />
                <span
                  className="transition-colors"
                  style={{ color: location === "/premium" ? "#C9A227" : "#D4AF3799" }}
                >
                  Premium
                </span>
                {location === "/premium" && (
                  <span className="ml-auto w-1.5 h-1.5 rounded-full" style={{ backgroundColor: "#C9A227" }} />
                )}
              </div>
            </Link>
          </div>
        </nav>

        <div className="px-3 pb-2 space-y-0.5 border-t border-border pt-3">
          {bottomItems.map(item => (
            <NavLink key={item.href} href={item.href} icon={item.icon} label={item.label} location={location} />
          ))}
        </div>

        <div className="p-3 border-t border-border">
          <div className="flex items-center gap-2.5 mb-3 px-1">
            <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center overflow-hidden shrink-0">
              {user?.avatarUrl ? (
                <img src={user.avatarUrl} alt={user.name} className="w-full h-full object-cover" />
              ) : (
                <span className="font-medium text-xs">{user?.name?.charAt(0).toUpperCase()}</span>
              )}
            </div>
            <div className="overflow-hidden flex-1 min-w-0">
              <p className="text-xs font-medium truncate">{user?.name}</p>
              <p className="text-[10px] text-muted-foreground truncate">{user?.email}</p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="w-full justify-start text-muted-foreground hover:text-foreground text-xs h-8"
            onClick={logout}
            data-testid="button-logout"
          >
            <LogOut className="w-3.5 h-3.5 mr-2" />
            {t("auth.logout")}
          </Button>
        </div>
      </aside>

      {/* Mobile drawer */}
      <div className="md:hidden">
        <MobileDrawer
          open={drawerOpen}
          onClose={() => setDrawerOpen(false)}
          location={location}
        />
      </div>

      {/* Main content */}
      <main className="flex-1 flex flex-col relative overflow-hidden min-w-0">

        {/* Mobile top bar */}
        <div className="md:hidden sticky top-0 z-30 flex items-center gap-2 px-3 py-2.5 bg-background/95 backdrop-blur-sm border-b border-border shrink-0">
          <button
            onClick={() => setDrawerOpen(true)}
            className="w-10 h-10 flex items-center justify-center rounded-xl hover:bg-secondary transition-colors shrink-0"
            aria-label="Abrir menu"
          >
            <Menu className="w-5 h-5" />
          </button>

          <span className="font-semibold text-base flex-1 truncate">
            {isHome ? "PoupaMais" : pageTitle}
          </span>

          <Link href="/premium">
            <div className="w-9 h-9 rounded-full bg-secondary flex items-center justify-center shrink-0 hover:bg-secondary/80 transition-colors">
              <Bell className="w-4 h-4 text-muted-foreground" />
            </div>
          </Link>
        </div>

        {/* Desktop back button */}
        {!isHome && (
          <div className="hidden md:block absolute top-4 left-4 z-30">
            <button
              onClick={handleBack}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors text-xs font-medium"
              aria-label="Voltar"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              Voltar
            </button>
          </div>
        )}

        <div className="flex-1 overflow-y-auto overflow-x-hidden">
          {children}
        </div>
      </main>
    </div>
  );
}
